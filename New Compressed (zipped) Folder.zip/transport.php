<?php
//include($_SERVER['DOCUMENT_ROOT']."/backend/transportBackend.php"); // might be required soon for now commented
//transport.php *Handles major aspects of the PHPDoge framework based on users choice*
// DreamingCoders
$mvcEnabled = "false";


$transport = "noMVC"; // Set to MVC or noMVC depending on how you want your framework to run. This variable is unused at the moment

$transportTypes = array("Forum", "Learning", "Blog", "Social Network");
?>
